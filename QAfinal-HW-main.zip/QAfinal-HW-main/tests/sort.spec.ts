import { test, expect } from '@playwright/test';
import { LoginPage } from '../page-objects/LoginPage';
import { InventoryPage } from '../page-objects/InventoryPage';

test.describe('Product Sorting Functionality', () => {
  let loginPage: LoginPage;
  let inventoryPage: InventoryPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    inventoryPage = new InventoryPage(page);

    await loginPage.goto();
    await loginPage.login(process.env.STANDARD_USER!, process.env.PASSWORD!);
    await inventoryPage.verifyPageLoaded();
  });

  test('should sort products alphabetically A to Z', async ({ page }) => {
    await inventoryPage.sortProductsBy('az');
    
    const productNames = await inventoryPage.getProductNames();
    const sortedNames = [...productNames].sort();
    
    expect(productNames).toEqual(sortedNames);
  });

  test('should sort products alphabetically Z to A', async ({ page }) => {
    await inventoryPage.sortProductsBy('za');
    
    const productNames = await inventoryPage.getProductNames();
    const sortedNames = [...productNames].sort().reverse();
    
    expect(productNames).toEqual(sortedNames);
  });

  test('should sort products by price low to high', async ({ page }) => {
    await inventoryPage.sortProductsBy('lohi');
    
    const prices = await inventoryPage.getProductPrices();
    const sortedPrices = [...prices].sort((a, b) => a - b);
    
    expect(prices).toEqual(sortedPrices);
  });

  test('should sort products by price high to low', async ({ page }) => {
    await inventoryPage.sortProductsBy('hilo');
    
    const prices = await inventoryPage.getProductPrices();
    const sortedPrices = [...prices].sort((a, b) => b - a);
    
    expect(prices).toEqual(sortedPrices);
  });
});
