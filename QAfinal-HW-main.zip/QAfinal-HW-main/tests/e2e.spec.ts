import { test, expect } from '@playwright/test';
import { LoginPage } from '../page-objects/LoginPage';
import { InventoryPage } from '../page-objects/InventoryPage';
import { CartPage } from '../page-objects/CartPage';
import { CheckoutPage } from '../page-objects/CheckoutPage';

test.describe('End-to-End Shopping Flow', () => {
  let loginPage: LoginPage;
  let inventoryPage: InventoryPage;
  let cartPage: CartPage;
  let checkoutPage: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    inventoryPage = new InventoryPage(page);
    cartPage = new CartPage(page);
    checkoutPage = new CheckoutPage(page);

    await loginPage.goto();
  });

  test('should complete purchase flow from login to checkout', async ({ page }) => {
    await loginPage.login(process.env.STANDARD_USER!, process.env.PASSWORD!);
    await inventoryPage.verifyPageLoaded();
    
    await inventoryPage.sortProductsBy('hilo');
    
    const itemName = 'Sauce Labs Fleece Jacket';
    await inventoryPage.addItemToCart(itemName);
    expect(await inventoryPage.getCartItemCount()).toBe(1);
    
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
    await cartPage.verifyItemInCart(itemName);
    
    await cartPage.checkout();
    await checkoutPage.verifyCheckoutStepOneLoaded();
    
    await checkoutPage.fillShippingInfo('najwa', 'yaseen', '12345');
    await checkoutPage.verifyCheckoutStepTwoLoaded();
    
    const totalPrice = await checkoutPage.getTotalPrice();
    expect(totalPrice).toBeGreaterThan(0);
    
    await checkoutPage.completeCheckout();
    await checkoutPage.verifyCheckoutComplete();
  });
});