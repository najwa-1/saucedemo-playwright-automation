import { test, expect } from '@playwright/test';
import { LoginPage } from '../page-objects/LoginPage';
import { InventoryPage } from '../page-objects/InventoryPage';
import { CartPage } from '../page-objects/CartPage';

test.describe('Shopping Cart Functionality', () => {
  let loginPage: LoginPage;
  let inventoryPage: InventoryPage;
  let cartPage: CartPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    inventoryPage = new InventoryPage(page);
    cartPage = new CartPage(page);

    await loginPage.goto();
    await loginPage.login(process.env.STANDARD_USER!, process.env.PASSWORD!);
    await inventoryPage.verifyPageLoaded();
  });

  test('should add item to cart', async ({ page }) => {
    const itemName = 'Sauce Labs Backpack';
    await inventoryPage.addItemToCart(itemName);
    
    expect(await inventoryPage.getCartItemCount()).toBe(1);
    
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
    await cartPage.verifyItemInCart(itemName);
  });

  test('should add multiple items to cart', async ({ page }) => {
    const items = ['Sauce Labs Backpack', 'Sauce Labs Bike Light'];
    
    for (const item of items) {
      await inventoryPage.addItemToCart(item);
    }
    
    expect(await inventoryPage.getCartItemCount()).toBe(items.length);
    
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
    
    for (const item of items) {
      await cartPage.verifyItemInCart(item);
    }
  });

  test('should remove item from cart on inventory page', async ({ page }) => {
    const itemName = 'Sauce Labs Backpack';
    
    await inventoryPage.addItemToCart(itemName);
    expect(await inventoryPage.getCartItemCount()).toBe(1);
    
    await inventoryPage.removeItemFromCart(itemName);
    expect(await inventoryPage.getCartItemCount()).toBe(0);
  });

  test('should remove item from cart page', async ({ page }) => {
    const itemName = 'Sauce Labs Backpack';
    
    await inventoryPage.addItemToCart(itemName);
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
    
    await cartPage.removeItem(itemName);
    await cartPage.verifyItemNotInCart(itemName);
    expect(await cartPage.getCartItemCount()).toBe(0);
  });

  test('should continue shopping from cart page', async ({ page }) => {
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
    
    await cartPage.continueShopping();
    await inventoryPage.verifyPageLoaded();
  });
});
