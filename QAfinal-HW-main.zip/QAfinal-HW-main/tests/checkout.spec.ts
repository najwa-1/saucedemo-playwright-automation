import { test, expect } from '@playwright/test';
import { LoginPage } from '../page-objects/LoginPage';
import { InventoryPage } from '../page-objects/InventoryPage';
import { CartPage } from '../page-objects/CartPage';
import { CheckoutPage } from '../page-objects/CheckoutPage';

test.describe('Checkout Process', () => {
  let loginPage: LoginPage;
  let inventoryPage: InventoryPage;
  let cartPage: CartPage;
  let checkoutPage: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    inventoryPage = new InventoryPage(page);
    cartPage = new CartPage(page);
    checkoutPage = new CheckoutPage(page);

    await loginPage.goto();
    await loginPage.login(process.env.STANDARD_USER!, process.env.PASSWORD!);
    await inventoryPage.verifyPageLoaded();
   await inventoryPage.addItemToCart('Sauce Labs Backpack');
    await inventoryPage.goToCart();
    await cartPage.verifyPageLoaded();
  });

  test('should complete checkout with valid information', async ({ page }) => {
    await cartPage.checkout();
    await checkoutPage.verifyCheckoutStepOneLoaded();
    
    await checkoutPage.fillShippingInfo('najwa', 'yaseen', '12345');
    await checkoutPage.verifyCheckoutStepTwoLoaded();
    
    const totalPrice = await checkoutPage.getTotalPrice();
    expect(totalPrice).toBeGreaterThan(0);
    
    await checkoutPage.completeCheckout();
    await checkoutPage.verifyCheckoutComplete();
  });

  test('should show error with missing first name', async ({ page }) => {
    await cartPage.checkout();
    
    await checkoutPage.fillShippingInfo('', 'yaseen', '12345');
    await checkoutPage.verifyErrorMessage('First Name is required');
  });

  test('should show error with missing last name', async ({ page }) => {
    await cartPage.checkout();
    
    await checkoutPage.fillShippingInfo('najwa', '', '12345');
    await checkoutPage.verifyErrorMessage('Last Name is required');
  });

  test('should show error with missing postal code', async ({ page }) => {
    await cartPage.checkout();
    
    await checkoutPage.fillShippingInfo('najwa', 'yaseen', '');
    await checkoutPage.verifyErrorMessage('Postal Code is required');
  });
});