import { test, expect } from '@playwright/test';
import { LoginPage } from '../page-objects/LoginPage';
import { InventoryPage } from '../page-objects/InventoryPage';

test.describe('Login Functionality', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test('should login with valid credentials', async ({ page }) => {
    const inventoryPage = new InventoryPage(page);
    await loginPage.login(process.env.STANDARD_USER!, process.env.PASSWORD!);
    await inventoryPage.verifyPageLoaded();
  });

  test('should show error with locked out user', async ({ page }) => {
    await loginPage.login(process.env.LOCKED_OUT_USER!, process.env.PASSWORD!);
    await loginPage.verifyErrorMessage('Sorry, this user has been locked out');
  });

  test('should show error with invalid credentials', async ({ page }) => {
    await loginPage.login('invalid_user', 'invalid_password');
    await loginPage.verifyErrorMessage('Username and password do not match');
  });

  test('should show error when username is missing', async ({ page }) => {
    await loginPage.login('', process.env.PASSWORD!);
    await loginPage.verifyErrorMessage('Username is required');
  });

  test('should show error when password is missing', async ({ page }) => {
    await loginPage.login(process.env.STANDARD_USER!, '');
    await loginPage.verifyErrorMessage('Password is required');
  });
});