# Test info

- Name: Product Sorting Functionality >> should sort products alphabetically Z to A
- Location: C:\Users\Najwa\OneDrive\Desktop\sauce-demo-tests\tests\sort.spec.ts:27:7

# Error details

```
Error: locator.selectOption: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('[data-test="product_sort_container"]')

    at InventoryPage.sortProductsBy (C:\Users\Najwa\OneDrive\Desktop\sauce-demo-tests\page-objects\InventoryPage.ts:43:29)
    at C:\Users\Najwa\OneDrive\Desktop\sauce-demo-tests\tests\sort.spec.ts:28:25
```

# Page snapshot

```yaml
- button "Open Menu"
- img "Open Menu"
- text: Swag Labs Products Name (A to Z)
- combobox:
  - option "Name (A to Z)" [selected]
  - option "Name (Z to A)"
  - option "Price (low to high)"
  - option "Price (high to low)"
- link "Sauce Labs Backpack":
  - /url: "#"
  - img "Sauce Labs Backpack"
- link "Sauce Labs Backpack":
  - /url: "#"
- text: carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection. $29.99
- button "Add to cart"
- link "Sauce Labs Bike Light":
  - /url: "#"
  - img "Sauce Labs Bike Light"
- link "Sauce Labs Bike Light":
  - /url: "#"
- text: A red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included. $9.99
- button "Add to cart"
- link "Sauce Labs Bolt T-Shirt":
  - /url: "#"
  - img "Sauce Labs Bolt T-Shirt"
- link "Sauce Labs Bolt T-Shirt":
  - /url: "#"
- text: Get your testing superhero on with the Sauce Labs bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt. $15.99
- button "Add to cart"
- link "Sauce Labs Fleece Jacket":
  - /url: "#"
  - img "Sauce Labs Fleece Jacket"
- link "Sauce Labs Fleece Jacket":
  - /url: "#"
- text: It's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office. $49.99
- button "Add to cart"
- link "Sauce Labs Onesie":
  - /url: "#"
  - img "Sauce Labs Onesie"
- link "Sauce Labs Onesie":
  - /url: "#"
- text: Rib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel. $7.99
- button "Add to cart"
- link "Test.allTheThings() T-Shirt (Red)":
  - /url: "#"
  - img "Test.allTheThings() T-Shirt (Red)"
- link "Test.allTheThings() T-Shirt (Red)":
  - /url: "#"
- text: This classic Sauce Labs t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton. $15.99
- button "Add to cart"
- contentinfo:
  - list:
    - listitem:
      - link "Twitter":
        - /url: https://twitter.com/saucelabs
    - listitem:
      - link "Facebook":
        - /url: https://www.facebook.com/saucelabs
    - listitem:
      - link "LinkedIn":
        - /url: https://www.linkedin.com/company/sauce-labs/
  - text: © 2025 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy
```

# Test source

```ts
   1 | import { Page, Locator, expect } from '@playwright/test';
   2 |
   3 | export class InventoryPage {
   4 |   readonly page: Page;
   5 |   readonly title: Locator;
   6 |   readonly inventoryItems: Locator;
   7 |   readonly sortDropdown: Locator;
   8 |   readonly shoppingCartBadge: Locator;
   9 |   readonly shoppingCartLink: Locator;
  10 |
  11 |   constructor(page: Page) {
  12 |     this.page = page;
  13 |     this.title = page.locator('.title');
  14 |     this.inventoryItems = page.locator('.inventory_item');
  15 |     this.sortDropdown = page.locator('[data-test="product_sort_container"]');
  16 |     this.shoppingCartBadge = page.locator('.shopping_cart_badge');
  17 |     this.shoppingCartLink = page.locator('.shopping_cart_link');
  18 |   }
  19 |
  20 |   async verifyPageLoaded() {
  21 |     await expect(this.title).toHaveText('Products');
  22 |     await expect(this.page).toHaveURL(/inventory.html/);
  23 |   }
  24 |
  25 |   async addItemToCart(itemName: string) {
  26 |     const item = this.page.locator('.inventory_item').filter({ hasText: itemName });
  27 |     await item.locator('[data-test^="add-to-cart"]').click();
  28 |   }
  29 |
  30 |   async removeItemFromCart(itemName: string) {
  31 |     const item = this.page.locator('.inventory_item').filter({ hasText: itemName });
  32 |     await item.locator('[data-test^="remove"]').click();
  33 |   }
  34 |
  35 |   async getCartItemCount() {
  36 |     if (await this.shoppingCartBadge.isVisible()) {
  37 |       return parseInt(await this.shoppingCartBadge.textContent() || '0');
  38 |     }
  39 |     return 0;
  40 |   }
  41 |
  42 |   async sortProductsBy(sortOption: string) {
> 43 |     await this.sortDropdown.selectOption(sortOption);
     |                             ^ Error: locator.selectOption: Test timeout of 30000ms exceeded.
  44 |   }
  45 |
  46 |   async getProductNames() {
  47 |     return await this.page.locator('.inventory_item_name').allTextContents();
  48 |   }
  49 |
  50 |   async getProductPrices() {
  51 |     const priceTexts = await this.page.locator('.inventory_item_price').allTextContents();
  52 |     return priceTexts.map(price => parseFloat(price.replace('$', '')));
  53 |   }
  54 |
  55 |   async goToCart() {
  56 |     await this.shoppingCartLink.click();
  57 |   }
  58 | }
```