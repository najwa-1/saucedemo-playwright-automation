import { Page, Locator, expect } from '@playwright/test';

export class CartPage {
  readonly page: Page;
  readonly title: Locator;
  readonly cartItems: Locator;
  readonly checkoutButton: Locator;
  readonly continueShoppingButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.title = page.locator('.title');
    this.cartItems = page.locator('.cart_item');
    this.checkoutButton = page.locator('[data-test="checkout"]');
    this.continueShoppingButton = page.locator('[data-test="continue-shopping"]');
  }

  async verifyPageLoaded() {
    await expect(this.title).toHaveText('Your Cart');
    await expect(this.page).toHaveURL(/cart.html/);
  }

  async removeItem(itemName: string) {
    const item = this.cartItems.filter({ hasText: itemName });
    await item.locator('[data-test^="remove"]').click();
  }

  async verifyItemInCart(itemName: string) {
    const item = this.cartItems.filter({ hasText: itemName });
    await expect(item).toBeVisible();
  }

  async verifyItemNotInCart(itemName: string) {
    const items = await this.page.locator('.inventory_item_name').allTextContents();
    expect(items).not.toContain(itemName);
  }

  async checkout() {
    await this.checkoutButton.click();
  }

  async continueShopping() {
    await this.continueShoppingButton.click();
  }

  async getCartItemCount() {
    return await this.cartItems.count();
  }
}